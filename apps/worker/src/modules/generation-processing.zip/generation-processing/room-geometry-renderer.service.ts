import { Injectable } from '@nestjs/common';
import { createHash } from 'node:crypto';
import sharp from 'sharp';
import { StorageService } from '../storage/storage.service.js';

type PolygonPoint = { x: number; y: number };
type RoomOpening = {
  kind: 'WINDOW' | 'DOOR';
  wallSegmentIndex: number;
  positionRatio: number;
  widthCm: number | null;
};
type GeometryRoom = {
  id: string;
  name: string;
  roomType: string | null;
  widthCm: number | null;
  depthCm: number | null;
  ceilingHeightCm: number | null;
  polygon: unknown;
  openings: RoomOpening[];
};

@Injectable()
export class RoomGeometryRendererService {
  constructor(private readonly storageService: StorageService) {}

  getFingerprint(room: GeometryRoom, defaultCeilingHeightCm: number) {
    return createHash('sha256')
      .update(
        JSON.stringify({
          polygon: room.polygon,
          openings: room.openings.map((opening) => ({
            kind: opening.kind,
            wallSegmentIndex: opening.wallSegmentIndex,
            positionRatio: opening.positionRatio,
            widthCm: opening.widthCm,
          })),
          roomType: room.roomType,
          widthCm: room.widthCm,
          depthCm: room.depthCm,
          ceilingHeightCm:
            room.ceilingHeightCm ?? defaultCeilingHeightCm,
          cameraWall: this.getCameraWall(room),
        }),
      )
      .digest('hex');
  }

  async renderReference(input: {
    room: GeometryRoom;
    projectId: string;
    defaultCeilingHeightCm: number;
  }) {
    const svg = this.buildSvg(
      input.room,
      input.defaultCeilingHeightCm,
    );
    const buffer = await sharp(Buffer.from(svg)).png().toBuffer();
    return this.storageService.uploadBuffer({
      buffer,
      contentType: 'image/png',
      folder: `generation/developer-geometry/${input.projectId}`,
    });
  }

  getCameraWall(room: GeometryRoom) {
    const polygon = this.getPolygon(room);
    const occupiedWalls = new Set(
      room.openings.map((opening) => opening.wallSegmentIndex),
    );
    let selectedWall = 0;
    let selectedLength = -1;
    polygon.forEach((start, index) => {
      if (occupiedWalls.has(index)) return;
      const end = polygon[(index + 1) % polygon.length];
      const length = (end.x - start.x) ** 2 + (end.y - start.y) ** 2;
      if (length > selectedLength) {
        selectedWall = index;
        selectedLength = length;
      }
    });
    return selectedWall;
  }

  private buildSvg(room: GeometryRoom, defaultCeilingHeightCm: number) {
    const polygon = this.getPolygon(room);
    const minX = Math.min(...polygon.map((point) => point.x));
    const maxX = Math.max(...polygon.map((point) => point.x));
    const minY = Math.min(...polygon.map((point) => point.y));
    const maxY = Math.max(...polygon.map((point) => point.y));
    const scale = Math.min(
      760 / Math.max(maxX - minX, 0.001),
      760 / Math.max(maxY - minY, 0.001),
    );
    const drawingWidth = (maxX - minX) * scale;
    const drawingHeight = (maxY - minY) * scale;
    const offsetX = 512 - drawingWidth / 2;
    const offsetY = 535 - drawingHeight / 2;
    const toCanvas = (point: PolygonPoint) => ({
      x: offsetX + (point.x - minX) * scale,
      y: offsetY + (point.y - minY) * scale,
    });
    const points = polygon
      .map((point) => {
        const canvasPoint = toCanvas(point);
        return `${canvasPoint.x},${canvasPoint.y}`;
      })
      .join(' ');
    const walls = polygon
      .map((start, index) => {
        const end = polygon[(index + 1) % polygon.length];
        const midpoint = toCanvas({
          x: (start.x + end.x) / 2,
          y: (start.y + end.y) / 2,
        });
        const x = midpoint.x;
        const y = midpoint.y;
        return `<text x="${x}" y="${y}" text-anchor="middle" class="wall">Стена ${index}</text>`;
      })
      .join('');
    const openings = room.openings
      .map((opening) => {
        const start = polygon[opening.wallSegmentIndex] ?? polygon[0];
        const end =
          polygon[(opening.wallSegmentIndex + 1) % polygon.length] ?? start;
        const point = toCanvas({
          x: start.x + (end.x - start.x) * opening.positionRatio,
          y: start.y + (end.y - start.y) * opening.positionRatio,
        });
        const x = point.x;
        const y = point.y;
        const color = opening.kind === 'WINDOW' ? '#0284c7' : '#f59e0b';
        const label = opening.kind === 'WINDOW' ? 'ОКНО' : 'ДВЕРЬ';
        return `<circle cx="${x}" cy="${y}" r="15" fill="${color}" stroke="#fff" stroke-width="4"/><text x="${x}" y="${y - 24}" text-anchor="middle" class="opening">${label}${opening.widthCm ? ` ${opening.widthCm} см` : ''}</text>`;
      })
      .join('');
    const cameraWall = this.getCameraWall(room);
    const hasDimensions = Boolean(room.widthCm && room.depthCm);
    const areaM2 = hasDimensions
      ? ((room.widthCm as number) * (room.depthCm as number)) / 10_000
      : null;
    const compactRoom = areaM2 !== null && areaM2 < 4;
    const dimensions = hasDimensions
      ? `${((room.widthCm as number) / 100).toFixed(2)} м × ${((room.depthCm as number) / 100).toFixed(2)} м (${room.widthCm} × ${room.depthCm} см)`
      : 'размеры не указаны';
    const scaleBarWidth = hasDimensions
      ? (drawingWidth * 100) / (room.widthCm as number)
      : 0;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
      <rect width="1024" height="1024" fill="#f8fafc"/>
      <style>.title{font:700 28px sans-serif;fill:#111827}.meta{font:20px sans-serif;fill:#475569}.compact{font:700 18px sans-serif;fill:#b45309}.wall{font:700 18px sans-serif;fill:#dc2626}.opening{font:700 16px sans-serif;fill:#0f172a}.scale{font:700 16px sans-serif;fill:#0f172a}</style>
      <text x="48" y="42" class="title">${escapeXml(room.name)}</text>
      <text x="48" y="70" class="meta">${dimensions} · ${areaM2?.toFixed(2) ?? '?'} м² · потолок ${room.ceilingHeightCm ?? defaultCeilingHeightCm} см</text>
      <text x="48" y="96" class="${compactRoom ? 'compact' : 'meta'}">${compactRoom ? 'КОМПАКТНАЯ КОМНАТА · ' : ''}камера напротив стены ${cameraWall}</text>
      <polygon points="${points}" fill="#fff" stroke="#0f172a" stroke-width="12" stroke-linejoin="round"/>
      ${walls}${openings}${hasDimensions ? `<line x1="48" y1="980" x2="${48 + scaleBarWidth}" y2="980" stroke="#0f172a" stroke-width="8"/><text x="${48 + scaleBarWidth / 2}" y="968" text-anchor="middle" class="scale">1 м</text>` : ''}
    </svg>`;
  }

  private getPolygon(room: GeometryRoom): PolygonPoint[] {
    if (!Array.isArray(room.polygon) || room.polygon.length < 3) {
      throw new Error(`Room "${room.name}" has invalid geometry`);
    }
    return room.polygon as PolygonPoint[];
  }
}

function escapeXml(value: string) {
  return value.replace(/[<>&"']/g, (character) => {
    const entities: Record<string, string> = {
      '<': '&lt;',
      '>': '&gt;',
      '&': '&amp;',
      '"': '&quot;',
      "'": '&apos;',
    };
    return entities[character];
  });
}
